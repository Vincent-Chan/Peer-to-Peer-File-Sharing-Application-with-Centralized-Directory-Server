/*
COMP4621 Lab 7 Q4:
Practical Exercise: Implement RDT 3.0 on top of UDP client server. 
(Hint: this will be needed in the programming project later)
*/

// Note: The code is highly depend on the code from COMP4621 Lab 5, Lab 6 and Lab 7 source codes and slides

#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

#define MAX 1024
#define PORT 6789

int main(){
	int sockfd, n;
	struct sockaddr_in server_addr, client_addr;
	// char buffer[MAX];

    // Newly added
    int length ;
    char sent_buffer[MAX] ;
    char received_buffer[MAX] ;
    char previous_buffer[MAX] ;

    // fill in all the buffers with '\0'
    explicit_bzero(sent_buffer, sizeof(sent_buffer)) ;
    explicit_bzero(received_buffer, sizeof(received_buffer)) ;
    explicit_bzero(previous_buffer, sizeof(previous_buffer)) ;


    // Newly added
    struct timeval TIMEVAL ;
    TIMEVAL.tv_sec = 3 ;
    TIMEVAL.tv_usec = 0 ;
	
	// socket create and verification
	// sockfd = socket(AF_INET, SOCK_STREAM, 0);

    // Newly added
    sockfd = socket(AF_INET, SOCK_DGRAM, 0) ;

	if (sockfd == -1){
		printf("Socket creation failed...\n");
		exit(0);
	}
	else
		printf("Socket successfully created...\n");

    // Newly added
    setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, (struct timeval*)&TIMEVAL, sizeof(struct timeval)) ;
		
	bzero(&server_addr, sizeof(server_addr));
	
	// assign IP, PORT
	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.s_addr = inet_addr("0.0.0.0");
	server_addr.sin_port = htons(PORT);

    n = 0 ;

    // Newly added
    while(1)
    {
        // fill in the buffer with '\0'
        explicit_bzero(sent_buffer, sizeof(sent_buffer)) ;
        explicit_bzero(received_buffer, sizeof(received_buffer)) ;

        printf("Enter the string : ");
		n = 0;
		while ((sent_buffer[n++] = getchar()) != '\n')
			;

        if ((strncmp(sent_buffer, "exit", 4)) == 0) 
        {
			printf("Client Exit...\n");
			// close the socket
			close(sockfd);
			break;
		}
        
        // send the buffer to server
        sendto(sockfd, (const char *)sent_buffer, strlen(sent_buffer), 0, (const struct sockaddr *) &server_addr, sizeof(server_addr)) ;

        while(1)
        {
            n = recvfrom(sockfd, (char *)received_buffer, MAX, 0, ( struct sockaddr *) &server_addr, &length) ;

            // Case I: The received message is identical with the previous messgae, duplication occur!
            if (strcmp(received_buffer, previous_buffer) == 0)
            {
                continue ;
            }
            // Case II: The received message is of length greater than 0
            else if (n > 0)
            {
                // fill in the previous buffer with '\0'
                explicit_bzero(previous_buffer, sizeof(previous_buffer)) ;

                // update the previous buffer
                stcpy(previous_buffer, received_buffer)

                break ;
            }
            // Case III: There is error when receiving the message or the received message is of length 0
            else
            {
                sendto(sockfd, (const char *)sent_buffer, strlen(sent_buffer), 0, (const struct sockaddr *) &server_addr, sizeof(server_addr)) ;

                continue ;
            }
        
        }

        received_buffer[n] = '\0' ;

        printf("From Server : %s", received_buffer) ;


        // fill in the buffer with '\0'
        explicit_bzero(sent_buffer, sizeof(sent_buffer)) ;
        explicit_bzero(received_buffer, sizeof(received_buffer)) ;
    }
	
	// connect the client socket to the server socket
	// if (connect(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr)) != 0) {
	// 	printf("Connection with the server failed...\n");
	// 	exit(0);
	// }
	// else
	// 	printf("Connected to the server...\n");
		
	// chat with the server
	// for (;;) {
	// 	bzero(buffer, sizeof(buffer));
	// 	printf("Enter the string : ");
	// 	n = 0;
	// 	while ((buffer[n++] = getchar()) != '\n')
	// 		;
	// 	write(sockfd, buffer, sizeof(buffer));
	// 	if ((strncmp(buffer, "exit", 4)) == 0) {
	// 		printf("Client Exit...\n");
	// 		// close the socket
	// 		close(sockfd);
	// 		break;
	// 	}
	// 	bzero(buffer, sizeof(buffer));
	// 	recv(sockfd, buffer, sizeof(buffer), 0);
	// 	printf("From Server : %s", buffer);
		
	// }
	/*
	bzero(buffer, sizeof(buffer));
	printf("Enter the string: ");
	//sleep(5);
	n = 0;
	while ((buffer[n++] = getchar()) != '\n')
		;
	send(sockfd, buffer, strlen(buffer), 0);
	
	bzero(buffer, sizeof(buffer));
	recv(sockfd, buffer, sizeof(buffer), 0);
	printf("From Server : %s", buffer);
	*/

    // Newly added
    close(sockfd) ;
	
	return 0;
}

